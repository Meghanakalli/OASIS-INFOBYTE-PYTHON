import json
from urllib.parse import urlencode
from urllib.request import urlopen
from urllib.error import URLError, HTTPError


GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
WEATHER_URL = "https://api.open-meteo.com/v1/forecast"


def get_json(url):
    with urlopen(url, timeout=15) as response:
        return json.loads(response.read().decode("utf-8"))


def find_city(city_name):
    params = urlencode({
        "name": city_name,
        "count": 1,
        "language": "en",
        "format": "json"
    })
    data = get_json(GEOCODING_URL + "?" + params)
    results = data.get("results", [])

    if not results:
        return None

    return results[0]


def get_weather(latitude, longitude):
    params = urlencode({
        "latitude": latitude,
        "longitude": longitude,
        "current": (
            "temperature_2m,relative_humidity_2m,"
            "apparent_temperature,weather_code,wind_speed_10m"
        ),
        "timezone": "auto"
    })
    return get_json(WEATHER_URL + "?" + params)


def describe_weather(code):
    descriptions = {
        0: "Clear sky",
        1: "Mainly clear",
        2: "Partly cloudy",
        3: "Overcast",
        45: "Fog",
        48: "Depositing rime fog",
        51: "Light drizzle",
        53: "Moderate drizzle",
        55: "Dense drizzle",
        61: "Slight rain",
        63: "Moderate rain",
        65: "Heavy rain",
        71: "Slight snow",
        73: "Moderate snow",
        75: "Heavy snow",
        80: "Rain showers",
        81: "Moderate rain showers",
        82: "Violent rain showers",
        95: "Thunderstorm"
    }
    return descriptions.get(code, "Weather condition unavailable")


def main():
    print("===== BASIC WEATHER APP =====")
    city_name = input("Enter city name: ").strip()

    if not city_name:
        print("Error: City name cannot be empty.")
        return

    try:
        city = find_city(city_name)

        if city is None:
            print("City not found. Please check the spelling and try again.")
            return

        weather_data = get_weather(city["latitude"], city["longitude"])
        current = weather_data["current"]

        print("\nWeather Report")
        print("------------------------------")
        print("City:", city["name"])
        if city.get("admin1"):
            print("Region:", city["admin1"])
        if city.get("country"):
            print("Country:", city["country"])
        print("Temperature:", current["temperature_2m"], "°C")
        print("Humidity:", current["relative_humidity_2m"], "%")
        print("Feels like:", current["apparent_temperature"], "°C")
        print("Weather:", describe_weather(current["weather_code"]))
        print("Wind speed:", current["wind_speed_10m"], "km/h")

    except (HTTPError, URLError, TimeoutError):
        print("Unable to connect to the weather service. Check your internet connection.")
    except (KeyError, ValueError, json.JSONDecodeError):
        print("Could not read the weather data. Please try again later.")


if __name__ == "__main__":
    main()
