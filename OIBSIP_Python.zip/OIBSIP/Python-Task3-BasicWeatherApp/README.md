# Basic Weather App

## Project
A command-line weather application written in Python. It looks up a city and retrieves its current weather using the free Open-Meteo services.

## Features
- Accepts a city name from the user.
- Finds the city's latitude and longitude using Open-Meteo Geocoding.
- Displays current temperature in Celsius, humidity, feels-like temperature, weather description and wind speed.
- Handles unknown cities and connection / data errors.

## Requirements
- Python 3.8 or later
- Internet connection
- No API key and no external Python packages required

## Run
Open a terminal in this folder and run:

```bash
python main.py
```

Enter a city name when prompted.

## Data source
- Geocoding: https://geocoding-api.open-meteo.com/
- Current weather: https://api.open-meteo.com/

The app uses the current-weather fields provided by Open-Meteo. Weather information requires an internet connection and may be unavailable if the service is down.

## Python concepts used
Functions, dictionaries, conditionals, exception handling, JSON, URL query parameters and HTTP requests using Python's standard library.
