import secrets
import string


def get_yes_no(message):
    while True:
        answer = input(message).strip().lower()
        if answer in ("y", "yes"):
            return True
        if answer in ("n", "no"):
            return False
        print("Please enter y or n.")


def generate_password(length, use_lower, use_upper, use_digits, use_symbols):
    groups = []

    if use_lower:
        groups.append(string.ascii_lowercase)
    if use_upper:
        groups.append(string.ascii_uppercase)
    if use_digits:
        groups.append(string.digits)
    if use_symbols:
        groups.append("!@#$%^&*()-_=+?")

    # Add at least one character from every selected group.
    password_chars = [secrets.choice(group) for group in groups]
    all_characters = "".join(groups)

    # Fill the remaining positions from all selected character groups.
    for _ in range(length - len(password_chars)):
        password_chars.append(secrets.choice(all_characters))

    # Securely shuffle the characters.
    secrets.SystemRandom().shuffle(password_chars)
    return "".join(password_chars)


def main():
    print("===== RANDOM PASSWORD GENERATOR =====")

    try:
        length = int(input("Enter password length (minimum 8): "))
    except ValueError:
        print("Error: Please enter a whole number.")
        return

    if length < 8:
        print("Error: Password length must be at least 8.")
        return

    use_lower = get_yes_no("Include lowercase letters? (y/n): ")
    use_upper = get_yes_no("Include uppercase letters? (y/n): ")
    use_digits = get_yes_no("Include numbers? (y/n): ")
    use_symbols = get_yes_no("Include symbols? (y/n): ")

    selected_count = sum([use_lower, use_upper, use_digits, use_symbols])

    if selected_count < 2:
        print("Error: Select at least two character types.")
        return

    password = generate_password(
        length, use_lower, use_upper, use_digits, use_symbols
    )

    print("\nGenerated password:", password)


if __name__ == "__main__":
    main()
