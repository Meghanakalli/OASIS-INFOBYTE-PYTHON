def calculate_bmi(weight, height):
    return weight / (height * height)


def get_category(bmi):
    if bmi < 18.5:
        return "Underweight"
    elif bmi < 25:
        return "Normal weight"
    elif bmi < 30:
        return "Overweight"
    else:
        return "Obesity"


def main():
    print("===== BMI CALCULATOR =====")

    try:
        weight = float(input("Enter your weight in kilograms: "))
        height = float(input("Enter your height in metres: "))

        if weight <= 0 or height <= 0:
            print("Error: Weight and height must be greater than zero.")
            return

        bmi = calculate_bmi(weight, height)

        print("\nYour BMI is:", round(bmi, 2))
        print("BMI Category:", get_category(bmi))

    except ValueError:
        print("Error: Please enter numbers only.")


if __name__ == "__main__":
    main()
