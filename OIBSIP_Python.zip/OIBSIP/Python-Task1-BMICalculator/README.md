# BMI Calculator

## Project
A beginner-friendly command-line BMI Calculator written in Python.

## Features
- Accepts weight in kilograms and height in metres.
- Calculates BMI using `weight / (height * height)`.
- Displays BMI rounded to two decimal places.
- Displays an approximate BMI category.
- Handles non-numeric and non-positive inputs.

## Requirements
- Python 3.8 or later
- No external packages required

## Run
Open a terminal in this folder and run:

```bash
python main.py
```

## Example
```text
===== BMI CALCULATOR =====
Enter your weight in kilograms: 60
Enter your height in metres: 1.65

Your BMI is: 22.04
BMI Category: Normal weight
```

## Formula
BMI = weight (kg) / height (m)²

## Note
BMI is a general screening measure and is not a medical diagnosis.
